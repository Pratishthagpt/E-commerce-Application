package dev.pratishtha.project.CartService.security;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserValidateDto {

    private String token;
}
