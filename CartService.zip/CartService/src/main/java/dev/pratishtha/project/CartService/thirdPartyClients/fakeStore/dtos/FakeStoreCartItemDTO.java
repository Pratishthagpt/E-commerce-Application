package dev.pratishtha.project.CartService.thirdPartyClients.fakeStore.dtos;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FakeStoreCartItemDTO {

    private String productId;
    private int quantity;

}
