package dev.pratishtha.project.userService.exceptions;

public class SessionNotFoundException extends RuntimeException {
    public SessionNotFoundException(String s) {
        super(s);
    }
}
