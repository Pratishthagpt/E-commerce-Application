package dev.pratishtha.project.userService.models;

public enum SessionStatus {
    ACTIVE,
    ENDED
}
