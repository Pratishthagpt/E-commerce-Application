package dev.pratishtha.project.userService.dtos;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreateRoleRequestDto {

    private String roleName;
}
