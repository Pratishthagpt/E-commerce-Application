package dev.pratishtha.project.userService.dtos;

import dev.pratishtha.project.userService.models.Role;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RoleDto {

    private Role role;
}
