package dev.pratishtha.project.productService.security;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserValidateDto {
    private String token;
}
