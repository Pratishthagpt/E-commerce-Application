package dev.pratishtha.project.productService.models;

public class SqlQueries {

    public static final String GET_ALL_PRODUCTS_WITH_LIMIT = "select * from product limit :limit";
}
