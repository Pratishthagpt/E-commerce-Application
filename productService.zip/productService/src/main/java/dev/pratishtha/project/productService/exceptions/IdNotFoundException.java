package dev.pratishtha.project.productService.exceptions;

public class IdNotFoundException extends Exception {
    public IdNotFoundException(String message) {
        super(message);
    }
}
