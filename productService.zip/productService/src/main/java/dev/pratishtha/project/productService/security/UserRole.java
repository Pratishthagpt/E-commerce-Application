package dev.pratishtha.project.productService.security;

public class UserRole {
    private String role;
}
